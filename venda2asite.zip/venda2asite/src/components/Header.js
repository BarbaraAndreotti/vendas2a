import (AppBar, Toolbar, Typography, Button @mui/material: from

import (Link} from 'react- router-dom':

function Header() {

return ( <AppBar position="static"> <Toolbar> <Typography variant="h6" sx={{ flexGrow: 1 }}> Loja Virtual </Typography> <Button color="inherit

component (Link) to="/">

Home </Button>
