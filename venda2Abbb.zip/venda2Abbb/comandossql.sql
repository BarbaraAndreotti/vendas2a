create database vendas2a;
use vendas2a;
select 1 + 1;
select now();
select concat('Birth',' ','Code');
select concat('Birth',' ','Code') as empresaTI;